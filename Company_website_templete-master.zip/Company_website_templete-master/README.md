![](https://github.com/sitamadex11/CovidHelp/blob/develop/Assets/HackOctoberFestBanner.png)
![Minimum API Level](https://img.shields.io/badge/Min%20API%20Level-23-green)
![Maximum API Level](https://img.shields.io/badge/Max%20API%20Level-30-orange)
![GitHub repo size](https://img.shields.io/github/repo-size/sitamadex11/CovidHelp)
[![License](https://img.shields.io/badge/license-MIT-%2397ca00.svg)](https://github.com/sitamadex11/CovidHelp/blob/develop/LICENSE)
[![Open Source Love svg1](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)](https://github.com/ellerbrock/open-source-badges/) 
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](http://makeapullrequest.com) 
![contributions welcome](https://img.shields.io/static/v1.svg?label=Contributions&message=Welcome&color=0059b3&style=flat-square) 
![Maintenance](https://img.shields.io/maintenance/yes/2021)

# Company_website_templete
Basic company website template designed  using bootstap,HTML,CSS and JS.
Best for Beginner.


 WEBSITE SCREENSHOT

![image](https://user-images.githubusercontent.com/72190187/124345953-b2522680-dbf9-11eb-8cc7-05ff615abdf2.png)
